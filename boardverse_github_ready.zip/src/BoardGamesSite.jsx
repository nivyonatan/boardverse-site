import React from "react";

export default function BoardGamesSite() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {/* Header */}
      <header className="flex items-center justify-between px-10 py-6 border-b border-white/10 backdrop-blur-xl sticky top-0">
        <h1 className="text-2xl font-semibold tracking-tight">BoardVerse</h1>
        <nav className="space-x-10 text-lg hidden md:block">
          <a className="hover:text-gray-300 transition" href="#community">Community</a>
          <a className="hover:text-gray-300 transition" href="#games">Games</a>
          <a className="hover:text-gray-300 transition" href="#events">Events</a>
          <a className="hover:text-gray-300 transition" href="#store">Store</a>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative text-center py-32 px-6">
        <img src="/banner.jpg" alt="Board games banner" className="absolute inset-0 w-full h-full object-cover opacity-30" />
        <div className="relative z-10">
          <h2 className="text-6xl md:text-7xl font-semibold mb-6 tracking-tight">עולם של משחקי לוח.</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">קהילה אחת. אלפי משחקים. חוויות שמחברות אנשים מחדש.</p>
        </div>
      </section>

      {/* Games Showcase */}
      <section id="games" className="px-10 py-24">
        <h3 className="text-4xl font-semibold mb-12 tracking-tight text-center">משחקים מובילים בקהילה</h3>
        <div className="grid md:grid-cols-3 gap-10">
          {["Catan", "Ticket to Ride", "Wingsspan"].map((game) => (
            <div className="bg-white/5 rounded-2xl p-8 backdrop-blur-xl border border-white/10 text-center" key={game}>
              <img src={`/${game.toLowerCase().replace(/ /g,'-')}.jpg`} alt={game} className="h-40 w-full object-cover rounded-xl mb-6" />
              <h4 className="text-2xl font-medium mb-2">{game}</h4>
              <p className="text-gray-400 text-sm">משחק אסטרטגיה מוביל עם קהילה עצומה ברחבי העולם.</p>
            </div>
          ))}
        </div>
      </section>

      {/* Community */}
      <section id="community" className="px-10 py-24 bg-white/5 border-y border-white/10 text-center">
        <h3 className="text-4xl font-semibold mb-6 tracking-tight">קהילה מחוברת.</h3>
        <p className="text-lg text-gray-300 max-w-3xl mx-auto">פורומים, קבוצות דיון, מפגשי משחקים, מדריכים לשחקנים חדשים, וסקירות עומק על כל משחקי הקופסה בעולם.</p>
      </section>

      {/* Events */}
      <section id="events" className="px-10 py-24">
        <h3 className="text-4xl font-semibold mb-12 tracking-tight text-center">אירועים קרובים</h3>
        <div className="space-y-6 max-w-2xl mx-auto">
          {[
            { name: "ליל משחקי לוח בתל אביב", date: "12 בדצמבר" },
            { name: "טורניר Ticket to Ride הארצי", date: "3 בינואר" },
            { name: "מפגש קהילה – משחקים חדשים", date: "15 בינואר" },
          ].map((event) => (
            <div className="bg-white/5 p-6 rounded-xl border border-white/10 backdrop-blur-xl flex justify-between" key={event.name}>
              <span className="text-xl">{event.name}</span>
              <span className="text-gray-400">{event.date}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Games – Detailed Section */}
      <section id="popular-games" className="px-10 py-24 bg-white/5 border-y border-white/10 text-center">
        <h3 className="text-4xl font-semibold mb-12 tracking-tight">משחקים פופולריים – סקירה מעמיקה</h3>
        <div className="space-y-20 max-w-3xl mx-auto text-left">

          <div className="bg-white/5 rounded-2xl p-8 backdrop-blur-xl border border-white/10">
            <img src="/wingspan.jpg" alt="Wingspan" className="h-64 w-full object-cover rounded-xl mb-6" />
            <h4 className="text-3xl font-semibold mb-4">Wingspan</h4>
            <p className="text-gray-300 text-lg">משחק בניית מנוע שבו תנהל שמורת ציפורים, תאסוף מזון, תטיל ביצים ותמשוך מינים נדירים. חוויה אסתטית ואסטרטגית מהטובות בעולם.</p>
          </div>

          <div className="bg-white/5 rounded-2xl p-8 backdrop-blur-xl border border-white/10">
            <img src="/catan.jpg" alt="Catan" className="h-64 w-full object-cover rounded-xl mb-6" />
            <h4 className="text-3xl font-semibold mb-4">Catan</h4>
            <p className="text-gray-300 text-lg">המשחק האיקוני שבו אתה אוסף משאבים, מנהל סחר ובונה התיישבות באי קאטאן. אחת מאבני הדרך בעולם משחקי הלוח.</p>
          </div>

          <div className="bg-white/5 rounded-2xl p-8 backdrop-blur-xl border border-white/10">
            <img src="/ticket-to-ride.jpg" alt="Ticket to Ride" className="h-64 w-full object-cover rounded-xl mb-6" />
            <h4 className="text-3xl font-semibold mb-4">Ticket to Ride</h4>
            <p className="text-gray-300 text-lg">משחק בניית מסילות רכבת בין ערים ברחבי העולם. פשוט, קליל, וכיפי לכל הגילאים.</p>
          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="text-center py-10 text-gray-500 text-sm border-t border-white/10">
        BoardVerse © {new Date().getFullYear()} — כל הזכויות שמורות.
      </footer>
    </div>
  );
}
