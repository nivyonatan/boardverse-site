export default function Footer(){
  return (
    <div className='text-center p-10 text-gray-400 border-t border-white/10 mt-10'>
      BoardVerse © 2025 — כל הזכויות שמורות.
    </div>
  )
}
