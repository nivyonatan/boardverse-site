import { Link } from 'react-router-dom'

export default function Header() {
  return (
    <div className='w-full bg-black/40 backdrop-blur-xl border-b border-white/10 p-5 flex gap-6 text-xl'>
      <Link to='/'>בית</Link>
      <Link to='/games'>משחקים</Link>
      <Link to='/events'>אירועים</Link>
      <Link to='/community'>קהילה</Link>
      <Link to='/store'>חנות</Link>
    </div>
  )
}
