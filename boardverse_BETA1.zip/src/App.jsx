import { Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import Games from './pages/Games'
import Events from './pages/Events'
import Community from './pages/Community'
import Store from './pages/Store'

export default function App() {
  return (
    <div>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/games" element={<Games />} />
        <Route path="/events" element={<Events />} />
        <Route path="/community" element={<Community />} />
        <Route path="/store" element={<Store />} />
      </Routes>
      <Footer />
    </div>
  )
}
